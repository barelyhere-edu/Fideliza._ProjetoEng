/* Testes automáticos da versão local.
   Como executar (na pasta fideliza-local):   node testes/teste-api.js

   O teste sobe um servidor próprio na porta 3999, com um banco de dados
   temporário (os dados reais da pasta "database" não são tocados), executa
   os casos de teste das regras de negócio e mostra o resultado de cada um. */
'use strict';
const { spawn } = require('child_process');
const fs = require('fs');
const http = require('http');
const os = require('os');
const path = require('path');

const PORTA = 3999;
const BASE = 'http://127.0.0.1:' + PORTA;
const pastaBanco = fs.mkdtempSync(path.join(os.tmpdir(), 'fideliza-teste-'));
const CNPJ = '11.222.333/0001-81';

let aprovados = 0;
const falhas = [];
function conferir(id, descricao, condicao, detalhe) {
  if (condicao) {
    aprovados += 1;
    console.log('  OK     ' + id + ' ' + descricao);
  } else {
    falhas.push(id);
    console.log('  FALHOU ' + id + ' ' + descricao + (detalhe ? ' -> ' + detalhe : ''));
  }
}
async function chamar(metodo, caminho, corpo, token) {
  const cabecalhos = {};
  if (token) cabecalhos.Authorization = 'Bearer ' + token;
  if (corpo !== undefined) cabecalhos['Content-Type'] = 'application/json';
  const resposta = await fetch(BASE + caminho, { method: metodo, headers: cabecalhos, body: corpo !== undefined ? JSON.stringify(corpo) : undefined });
  let dados = null;
  try {
    dados = await resposta.json();
  } catch (e) {
    dados = null;
  }
  return { status: resposta.status, dados: dados, codigo: dados && dados.erro ? dados.erro.codigo : null };
}
/** Pede um caminho exatamente como foi escrito (sem o navegador "arrumar" os "..") e devolve o status. */
function statusBruto(caminho) {
  return new Promise((resolver, rejeitar) => {
    const pedido = http.request({ host: '127.0.0.1', port: PORTA, path: caminho, method: 'GET' }, (resposta) => {
      resposta.resume();
      resposta.on('end', () => resolver(resposta.statusCode));
    });
    pedido.on('error', rejeitar);
    pedido.end();
  });
}
function esperarServidor() {
  return new Promise((resolver, rejeitar) => {
    const inicio = Date.now();
    (function tentar() {
      fetch(BASE + '/api/info')
        .then(() => resolver())
        .catch(() => {
          if (Date.now() - inicio > 8000) return rejeitar(new Error('O servidor de teste não iniciou.'));
          setTimeout(tentar, 150);
        });
    })();
  });
}

async function executar() {
  const email = 'cliente.teste@exemplo.com';
  const senha = 'segredo123';

  console.log('\nCadastro e login');
  let r = await chamar('POST', '/api/cadastro', { nome: 'Cliente Teste', email: email, senha: senha, consentimento: false });
  conferir('CT01', 'cadastro sem consentimento (LGPD) é recusado', r.status === 400 && r.codigo === 'SEM_CONSENTIMENTO', r.status + ' ' + r.codigo);
  r = await chamar('POST', '/api/cadastro', { nome: 'Cliente Teste', email: email, senha: '123', consentimento: true });
  conferir('CT02', 'cadastro com senha curta é recusado', r.status === 400 && r.codigo === 'SENHA_FRACA', r.status + ' ' + r.codigo);
  r = await chamar('POST', '/api/cadastro', { nome: 'Cliente Teste', email: email, senha: senha, consentimento: true });
  conferir('CT03', 'cadastro válido cria o cliente e abre a sessão', r.status === 201 && !!r.dados.token && r.dados.usuario.perfil === 'cliente', r.status + ' ' + r.codigo);
  r = await chamar('POST', '/api/cadastro', { nome: 'Outra Pessoa', email: email, senha: senha, consentimento: true });
  conferir('CT04', 'e-mail repetido é recusado', r.status === 409 && r.codigo === 'EMAIL_JA_CADASTRADO', r.status + ' ' + r.codigo);
  r = await chamar('POST', '/api/login', { perfil: 'cliente', identificador: email, senha: 'senha-errada' });
  conferir('CT05', 'login com senha errada é recusado', r.status === 401 && r.codigo === 'CREDENCIAIS_INVALIDAS', r.status + ' ' + r.codigo);
  r = await chamar('POST', '/api/login', { perfil: 'cliente', identificador: email, senha: senha });
  conferir('CT06', 'login do cliente com e-mail e senha', r.status === 200 && !!r.dados.token, r.status + ' ' + r.codigo);
  const cliente = r.dados.token;
  r = await chamar('POST', '/api/login', { perfil: 'vendedor', identificador: CNPJ, senha: 'vendedor123' });
  conferir('CT07', 'login do vendedor com CNPJ e senha', r.status === 200 && r.dados.usuario.perfil === 'vendedor', r.status + ' ' + r.codigo);
  const vendedor = r.dados.token;
  r = await chamar('POST', '/api/login', { perfil: 'administrador', identificador: CNPJ, senha: 'admin123' });
  conferir('CT08', 'login do administrador com CNPJ e senha', r.status === 200 && r.dados.usuario.perfil === 'administrador', r.status + ' ' + r.codigo);
  const admin = r.dados.token;

  console.log('\nProteção dos dados gravados');
  const usuariosTxt = fs.readFileSync(path.join(pastaBanco, 'usuarios.txt'), 'utf8');
  conferir('CT09', 'usuarios.txt não contém o e-mail completo', usuariosTxt.indexOf(email) < 0 && usuariosTxt.indexOf('cl***@exemplo.com') >= 0);
  conferir('CT10', 'usuarios.txt não contém nenhuma senha em texto puro', usuariosTxt.indexOf(senha) < 0 && usuariosTxt.indexOf('vendedor123') < 0 && usuariosTxt.indexOf('admin123') < 0);
  conferir('CT11', 'usuarios.txt não contém o CNPJ completo', usuariosTxt.indexOf('11222333000181') < 0 && usuariosTxt.indexOf(CNPJ) < 0);
  const fora = [];
  for (const caminho of ['/../server.js', '/..%2fserver.js', '/js/../../server.js', '/..%2fdatabase/usuarios.txt', '/database/usuarios.txt']) {
    fora.push(await statusBruto(caminho));
  }
  conferir('CT12', 'arquivos fora da pasta "public" (servidor e banco) não são entregues', fora.every((status) => status === 403 || status === 404), fora.join(' / '));

  console.log('\nControle de acesso por perfil');
  r = await chamar('GET', '/api/cartao');
  conferir('CT13', 'sem login não há acesso ao cartão', r.status === 401 && r.codigo === 'NAO_AUTENTICADO', r.status + ' ' + r.codigo);
  r = await chamar('POST', '/api/compras', { valor: 10 }, cliente);
  conferir('CT14', 'cliente não consegue confirmar compra', r.status === 403 && r.codigo === 'ACESSO_NEGADO', r.status + ' ' + r.codigo);
  r = await chamar('GET', '/api/vendas', undefined, vendedor);
  conferir('CT15', 'vendedor não acessa a tabela de vendas', r.status === 403 && r.codigo === 'ACESSO_NEGADO', r.status + ' ' + r.codigo);
  r = await chamar('GET', '/api/vendas', undefined, admin);
  conferir('CT16', 'administrador acessa a tabela de vendas', r.status === 200 && Array.isArray(r.dados.vendas), r.status + ' ' + r.codigo);

  console.log('\nCompra, QR Code e marcação');
  r = await chamar('GET', '/api/cartao', undefined, cliente);
  conferir('CT17', 'cartão novo começa com 0 de 10 marcações', r.status === 200 && r.dados.cartao.marcacoes.length === 0 && r.dados.cartao.limite === 10, JSON.stringify(r.dados));
  r = await chamar('POST', '/api/marcacoes', { codigo: 'ABCDEF' }, cliente);
  conferir('CT18', 'código inexistente não gera marcação', r.status === 404 && r.codigo === 'CODIGO_INVALIDO', r.status + ' ' + r.codigo);
  r = await chamar('POST', '/api/compras', { valor: 24.9 }, vendedor);
  conferir('CT19', 'vendedor confirma a compra e recebe um código de 6 caracteres', r.status === 201 && /^[A-Z2-9]{6}$/.test(r.dados.codigo), r.status + ' ' + r.codigo);
  const compra = r.dados;
  r = await chamar('GET', '/api/compras/' + compra.id, undefined, vendedor);
  conferir('CT20', 'compra confirmada fica pendente até a leitura', r.status === 200 && r.dados.status === 'pendente', JSON.stringify(r.dados));
  r = await chamar('POST', '/api/marcacoes', { codigo: compra.codigo.toLowerCase() }, cliente);
  conferir('CT21', 'leitura do código registra 1 marcação no cartão', r.status === 201 && r.dados.cartao.marcacoes.length === 1, r.status + ' ' + r.codigo);
  r = await chamar('POST', '/api/marcacoes', { codigo: compra.codigo }, cliente);
  conferir('CT22', 'o mesmo código não marca duas vezes', r.status === 409 && r.codigo === 'CODIGO_UTILIZADO', r.status + ' ' + r.codigo);
  r = await chamar('GET', '/api/compras/' + compra.id, undefined, vendedor);
  conferir('CT23', 'vendedor vê a compra como marcada, com o progresso do cliente', r.dados.status === 'marcada' && r.dados.cliente.marcacoes === 1, JSON.stringify(r.dados));

  // código expirado: altera a validade direto no arquivo e reinicia o servidor para reler o banco
  r = await chamar('POST', '/api/compras', {}, vendedor);
  const expirada = r.dados;
  return { cliente, vendedor, admin, email, senha, expirada };
}

async function executarParte2(ctx) {
  let r = await chamar('POST', '/api/login', { perfil: 'cliente', identificador: ctx.email, senha: ctx.senha });
  conferir('CT24', 'os dados continuam gravados depois de reiniciar o servidor', r.status === 200, r.status + ' ' + r.codigo);
  const cliente = r.dados.token;
  const vendedor = (await chamar('POST', '/api/login', { perfil: 'vendedor', identificador: CNPJ, senha: 'vendedor123' })).dados.token;
  const admin = (await chamar('POST', '/api/login', { perfil: 'administrador', identificador: CNPJ, senha: 'admin123' })).dados.token;
  r = await chamar('GET', '/api/cartao', undefined, ctx.cliente);
  conferir('CT25', 'a sessão antiga deixa de valer depois do reinício', r.status === 401, r.status + ' ' + r.codigo);
  r = await chamar('POST', '/api/marcacoes', { codigo: ctx.expirada.codigo }, cliente);
  conferir('CT26', 'código vencido (mais de 5 minutos) não gera marcação', r.status === 410 && r.codigo === 'CODIGO_EXPIRADO', r.status + ' ' + r.codigo);

  console.log('\nLimite de 10 marcações e cupom');
  let ultima = null;
  for (let i = 2; i <= 10; i++) {
    const compra = (await chamar('POST', '/api/compras', { valor: 10 + i }, vendedor)).dados;
    ultima = await chamar('POST', '/api/marcacoes', { codigo: compra.codigo }, cliente);
    if (i === 9) conferir('CT27', 'com 9 marcações ainda não existe cupom', ultima.dados.cartao.marcacoes.length === 9 && !ultima.dados.cupomGerado && ultima.dados.cupons.length === 0, JSON.stringify(ultima.dados));
  }
  conferir('CT28', 'a 10ª marcação completa o cartão', ultima.status === 201 && ultima.dados.cartao.marcacoes.length === 10 && ultima.dados.cartao.status === 'completo', ultima.status + ' ' + ultima.codigo);
  conferir('CT29', 'a 10ª marcação gera um cupom de 100%', !!ultima.dados.cupomGerado && /^CUP-[A-Z2-9]{6}$/.test(ultima.dados.cupomGerado.codigo), JSON.stringify(ultima.dados.cupomGerado));
  const cupom = ultima.dados.cupomGerado.codigo;
  const extra = (await chamar('POST', '/api/compras', {}, vendedor)).dados;
  r = await chamar('POST', '/api/marcacoes', { codigo: extra.codigo }, cliente);
  conferir('CT30', 'cartão completo não aceita a 11ª marcação', r.status === 409 && r.codigo === 'CARTAO_COMPLETO', r.status + ' ' + r.codigo);
  r = await chamar('POST', '/api/cartao/novo', {}, cliente);
  conferir('CT31', 'novo ciclo: cartão nº 2 começa com 0 marcações e o cupom é mantido', r.status === 201 && r.dados.cartao.numero === 2 && r.dados.cartao.marcacoes.length === 0 && r.dados.cupons.length === 1, JSON.stringify(r.dados));
  r = await chamar('POST', '/api/cartao/novo', {}, cliente);
  conferir('CT32', 'não é possível abrir novo cartão antes de completar o atual', r.status === 409 && r.codigo === 'CARTAO_INCOMPLETO', r.status + ' ' + r.codigo);
  r = await chamar('POST', '/api/marcacoes', { codigo: extra.codigo }, cliente);
  conferir('CT33', 'a compra recusada antes pode ser marcada no novo cartão', r.status === 201 && r.dados.cartao.marcacoes.length === 1, r.status + ' ' + r.codigo);

  console.log('\nCupom e consultas da loja');
  r = await chamar('POST', '/api/cupons/resgatar', { codigo: 'CUP-ZZZZZZ' }, vendedor);
  conferir('CT34', 'cupom inexistente é recusado', r.status === 404 && r.codigo === 'CUPOM_INVALIDO', r.status + ' ' + r.codigo);
  r = await chamar('POST', '/api/cupons/resgatar', { codigo: cupom }, cliente);
  conferir('CT35', 'cliente não consegue dar baixa no próprio cupom', r.status === 403, r.status + ' ' + r.codigo);
  r = await chamar('POST', '/api/cupons/resgatar', { codigo: cupom.toLowerCase() }, vendedor);
  conferir('CT36', 'vendedor valida o cupom de 100%', r.status === 200 && r.dados.desconto === 100, r.status + ' ' + r.codigo);
  r = await chamar('POST', '/api/cupons/resgatar', { codigo: cupom }, vendedor);
  conferir('CT37', 'o mesmo cupom não vale duas vezes', r.status === 409 && r.codigo === 'CUPOM_UTILIZADO', r.status + ' ' + r.codigo);
  r = await chamar('GET', '/api/resumo', undefined, vendedor);
  conferir('CT38', 'painel do dia: 11 marcações, 1 cupom gerado, 1 venda com cupom', r.dados.marcacoesHoje === 11 && r.dados.cuponsGeradosHoje === 1 && r.dados.vendasComCupomHoje === 1, JSON.stringify({ m: r.dados.marcacoesHoje, c: r.dados.cuponsGeradosHoje, v: r.dados.vendasComCupomHoje }));
  r = await chamar('GET', '/api/vendas?periodo=hoje&tipo=todas', undefined, admin);
  const hoje = r.dados.marcacoesPorDia[r.dados.marcacoesPorDia.length - 1];
  conferir('CT39', 'tabela de vendas: 13 registros (11 marcadas, 1 expirada, 1 com cupom)', r.dados.vendas.length === 13 && r.dados.totais.marcacoes === 11 && r.dados.totais.cupons === 1 && r.dados.vendas.filter((v) => v.status === 'expirada').length === 1, JSON.stringify(r.dados.totais) + ' ' + r.dados.vendas.length);
  conferir('CT40', 'marcações por dia: 11 marcações hoje', hoje.total === 11, JSON.stringify(hoje));
  r = await chamar('GET', '/api/vendas?periodo=hoje&tipo=cupom', undefined, admin);
  conferir('CT41', 'filtro "cupons" mostra só a venda com cupom', r.dados.vendas.length === 1 && r.dados.vendas[0].tipo === 'cupom', String(r.dados.vendas.length));
  conferir('CT42', 'a tabela mostra o e-mail do cliente censurado', r.dados.vendas[0].clienteContato === 'cl***@exemplo.com', r.dados.vendas[0].clienteContato);

  console.log('\nBloqueio por tentativas');
  let bloqueio = null;
  for (let i = 0; i < 6; i++) bloqueio = await chamar('POST', '/api/login', { perfil: 'cliente', identificador: 'outro@exemplo.com', senha: 'errada' + i });
  conferir('CT43', 'depois de 5 senhas erradas o login é bloqueado por um minuto', bloqueio.status === 429 && bloqueio.codigo === 'MUITAS_TENTATIVAS', bloqueio.status + ' ' + bloqueio.codigo);
  r = await chamar('POST', '/api/logout', {}, cliente);
  r = await chamar('GET', '/api/cartao', undefined, cliente);
  conferir('CT44', 'depois de sair, a sessão não vale mais', r.status === 401, r.status + ' ' + r.codigo);
}

function subirServidor() {
  const processo = spawn(process.execPath, [path.join(__dirname, '..', 'server.js')], {
    env: Object.assign({}, process.env, { PORT: String(PORTA), FIDELIZA_BANCO: pastaBanco }),
    stdio: 'ignore'
  });
  return processo;
}
function parar(processo) {
  return new Promise((resolver) => {
    processo.once('exit', resolver);
    processo.kill();
  });
}

(async function () {
  let servidor = subirServidor();
  let erroGeral = null;
  try {
    await esperarServidor();
    const ctx = await executar();
    // envelhece o código da compra pendente direto no arquivo .txt e reinicia o servidor
    await parar(servidor);
    const arquivo = path.join(pastaBanco, 'vendas.txt');
    const antigo = new Date(Date.now() - 60 * 60 * 1000).toISOString();
    const linhas = fs.readFileSync(arquivo, 'utf8').split('\n').map((linha) => {
      const campos = linha.split(';');
      if (campos[5] === ctx.expirada.codigo) campos[6] = antigo;
      return campos.join(';');
    });
    fs.writeFileSync(arquivo, linhas.join('\n'), 'utf8');
    servidor = subirServidor();
    await esperarServidor();
    await executarParte2(ctx);
  } catch (e) {
    erroGeral = e;
  }
  await parar(servidor);
  fs.rmSync(pastaBanco, { recursive: true, force: true });
  if (erroGeral) {
    console.error('\nO teste foi interrompido por um erro:', erroGeral);
    process.exit(1);
  }
  console.log('\nResultado: ' + aprovados + ' aprovados, ' + falhas.length + ' com falha' + (falhas.length ? ' (' + falhas.join(', ') + ')' : '') + '.\n');
  process.exit(falhas.length ? 1 : 0);
})();
