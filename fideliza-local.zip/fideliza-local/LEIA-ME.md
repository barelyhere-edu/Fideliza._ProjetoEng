# Fideliza — versão local (banco de dados em .txt)

Protótipo funcional do cartão fidelidade digital, com os dados gravados em arquivos de texto na pasta `database/`.

Esta versão precisa do **Node.js** porque uma página aberta direto no navegador não tem permissão para gravar arquivos no computador. O servidor (`server.js`) faz esse trabalho e não usa nenhuma biblioteca externa: não é preciso rodar `npm install`.

## Como executar

1. Instale o Node.js (versão LTS) em https://nodejs.org, se ainda não tiver.
2. Inicie o servidor de uma destas formas:
   - **Windows:** dois cliques em `iniciar.bat`.
   - **Linux ou macOS:** `./iniciar.sh`.
   - **Qualquer sistema:** abra um terminal nesta pasta e digite `node server.js`.
3. Abra **http://localhost:3000** no navegador.
4. Para encerrar, feche a janela do terminal ou pressione `Ctrl + C`.

Se a porta 3000 estiver ocupada, escolha outra:

- Windows (Prompt de Comando): `set PORT=8080 && node server.js`
- Linux ou macOS: `PORT=8080 node server.js`

## Contas para o teste

| Perfil | Como entrar | Senha |
| --- | --- | --- |
| Cliente | Toque em "Criar cadastro" e use qualquer e-mail | a que você escolher (mínimo de 6 caracteres) |
| Vendedor | CNPJ `11.222.333/0001-81` | `vendedor123` |
| Administrador | CNPJ `11.222.333/0001-81` | `admin123` |

As duas contas da loja são criadas automaticamente na primeira execução.

## Roteiro de teste sugerido

Use duas janelas: uma normal (loja) e uma anônima (cliente), ou o computador e um celular.

1. **Janela do cliente:** Entrar como Cliente → Criar cadastro → preencha nome, e-mail e senha.
2. **Janela da loja:** Entrar como Vendedor → "Confirmar compra" → "Gerar QR Code". Aparecem o QR Code e um código de 6 caracteres, válidos por 5 minutos.
3. **Janela do cliente:** "Ler QR Code" → aponte a câmera para o QR Code ou digite o código. O cartão ganha uma marcação e a tela da loja muda sozinha para "Compra marcada".
4. Repita os passos 2 e 3 até a 10ª marcação: o cartão fica completo e o cliente recebe um cupom (`CUP-XXXXXX`).
5. **Janela da loja:** "Validar cupom" → digite o código do cupom.
6. **Janela do cliente:** "Iniciar novo cartão" começa um novo ciclo.
7. **Janela da loja:** saia e entre como Administrador para ver a "Tabela de vendas".

Tentativas que o sistema deve recusar: usar o mesmo código duas vezes, usar um código depois de 5 minutos, marcar a 11ª compra no mesmo cartão, validar o mesmo cupom duas vezes e abrir a tabela de vendas como vendedor.

## Teste pelo celular

1. Conecte o celular na mesma rede Wi-Fi do computador.
2. Ao iniciar, o servidor mostra no terminal um endereço como `http://192.168.0.10:3000`. Abra esse endereço no celular (ou leia o QR Code da tela "Cartaz da loja").
3. O firewall do computador pode perguntar se o Node.js pode aceitar conexões: permita para redes privadas.

**Sobre a câmera:** os navegadores só liberam a câmera para páginas em `https://` ou em `localhost`. Por isso, ao abrir o site no celular pelo endereço da rede (`http://192.168...`), o leitor embutido não consegue ligar a câmera. Nesse caso há duas saídas, e as duas registram a marcação normalmente:

- ler o QR Code da compra com o **aplicativo de câmera do próprio celular**, que abre o site já na tela de marcação; ou
- **digitar o código de 6 caracteres** mostrado na tela do vendedor.

No computador, em `http://localhost:3000`, o leitor embutido funciona com a webcam.

## Onde os dados ficam

A pasta `database/` é criada na primeira execução:

| Arquivo | Conteúdo |
| --- | --- |
| `usuarios.txt` | clientes, vendedor e administrador |
| `cartoes.txt` | cartões fidelidade (um por ciclo de 10 marcações) |
| `marcacoes.txt` | cada marcação e a venda que a originou |
| `vendas.txt` | compras confirmadas e vendas com cupom |
| `cupons.txt` | cupons de 100% gerados e utilizados |
| `segredo.txt` | chave usada no código de verificação dos e-mails (não compartilhe) |

Cada arquivo tem os nomes das colunas na primeira linha e um registro por linha, com os campos separados por `;`.

### Como e-mails e senhas são protegidos

- **E-mail e CNPJ** são gravados censurados, por exemplo `ed***@gmail.com` e `11.***.***/0001-81`. Para reconhecer o usuário no login, o arquivo guarda também um código de verificação (HMAC-SHA-256) que não permite recuperar o e-mail original.
- **Senhas** nunca são gravadas. O arquivo guarda apenas o hash calculado com scrypt e um sal diferente para cada usuário. Não existe como "descriptografar" a senha.
- O servidor só entrega os arquivos da pasta `public/`. A pasta `database/` não é acessível pelo navegador.

Para **apagar todos os dados** e começar do zero, pare o servidor e exclua a pasta `database/`.

## Testes automatizados

```
node testes/teste-api.js
```

O comando sobe um servidor separado, com um banco temporário, e executa 44 casos de teste (cadastro e login, proteção dos dados gravados, controle de acesso por perfil, compra e marcação, limite de 10 marcações, cupom, consultas da loja e bloqueio por tentativas). O banco da pasta `database/` não é alterado.

## Estrutura

```
fideliza-local/
├── server.js            servidor e regras de negócio (Node.js, sem dependências)
├── iniciar.bat          atalho para Windows
├── iniciar.sh           atalho para Linux e macOS
├── public/              telas do aplicativo (HTML, CSS e JavaScript)
│   ├── index.html
│   ├── css/style.css
│   ├── js/              api.js conversa com o servidor; os demais arquivos são as telas
│   └── assets/fonts/
├── testes/teste-api.js  testes automatizados
└── database/            criada na primeira execução (arquivos .txt)
```

## Limites deste protótipo

- As sessões ficam na memória do servidor: ao reiniciar o servidor, é preciso fazer login de novo (os dados gravados continuam lá).
- O servidor usa `http`. Para uso real em uma loja seria necessário publicar o sistema com `https`, o que também libera a câmera no celular.
- Um arquivo `.txt` atende bem a uma demonstração; para muitos acessos simultâneos o indicado é um banco de dados de verdade.
