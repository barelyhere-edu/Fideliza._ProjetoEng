@echo off
chcp 65001 >nul
title Fideliza - versao local
cd /d "%~dp0"

where node >nul 2>nul
if errorlevel 1 (
  echo.
  echo O Node.js nao foi encontrado neste computador.
  echo Instale a versao LTS em https://nodejs.org e execute este arquivo de novo.
  echo.
  pause
  exit /b 1
)

echo O navegador sera aberto em http://localhost:3000 em instantes...
start "" /min cmd /c "timeout /t 2 /nobreak >nul & start http://localhost:3000"
node server.js
pause
