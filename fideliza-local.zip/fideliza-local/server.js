/* ==========================================================================
   Fideliza — servidor da VERSÃO LOCAL (banco de dados em arquivos .txt)

   Como executar:   node server.js        (depois abra http://localhost:3000)

   - Não usa nenhuma biblioteca externa: só os módulos que já vêm com o Node.js.
   - Entrega os arquivos da pasta "public" (as telas) e responde às chamadas
     /api/... feitas pelas telas.
   - Grava os dados na pasta "database", em arquivos .txt separados por ";".

   Proteção dos dados (RNF03, RNF08 / LGPD):
   - E-mail e CNPJ são gravados CENSURADOS (ex.: ed***@gmail.com). Para
     localizar o usuário no login é gravado também um código de verificação
     (HMAC-SHA-256) do identificador, que não permite recuperar o e-mail.
   - A senha nunca é gravada: guarda-se apenas o hash scrypt com sal
     individual. Não existe forma de "descriptografar" a senha.
   ========================================================================== */
'use strict';

const http = require('http');
const fs = require('fs');
const path = require('path');
const crypto = require('crypto');
const os = require('os');

/* ----- Configuração ----- */
const PORTA = Number(process.env.PORT) || 3000;
const PASTA_PUBLICA = path.join(__dirname, 'public');
const PASTA_BANCO = process.env.FIDELIZA_BANCO || path.join(__dirname, 'database');

const LIMITE_MARCACOES = 10; // RN02
const DESCONTO_CUPOM = 100; // RN05
const VALIDADE_QR_MINUTOS = 5;
const TAMANHO_SENHA_MINIMO = 6;
const DURACAO_SESSAO_MS = 8 * 60 * 60 * 1000; // 8 horas
const TENTATIVAS_LOGIN = 5; // tentativas erradas antes do bloqueio temporário
const BLOQUEIO_LOGIN_MS = 60 * 1000;
const TENTATIVAS_CODIGO = 10; // códigos errados por cliente antes do bloqueio temporário
const BLOQUEIO_CODIGO_MS = 5 * 60 * 1000;
const TAMANHO_MAXIMO_CORPO = 10 * 1024;

// Alfabeto sem caracteres que se confundem (I, O, 0 e 1).
const ALFABETO = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789';

// Contas da loja criadas na primeira execução (os clientes se cadastram pelo aplicativo).
const CNPJ_LOJA = '11222333000181';
const CONTAS_INICIAIS = [
  { perfil: 'vendedor', nome: 'Vendedor', identificador: CNPJ_LOJA, senha: 'vendedor123' },
  { perfil: 'administrador', nome: 'Administrador', identificador: CNPJ_LOJA, senha: 'admin123' }
];

/* ==========================================================================
   Banco de dados em .txt
   Cada tabela é um arquivo: a primeira linha traz os nomes das colunas e as
   demais trazem um registro por linha, com os campos separados por ";".
   ========================================================================== */
const TABELAS = {
  usuarios: ['id', 'perfil', 'nome', 'identificador_censurado', 'identificador_verificacao', 'senha_sal', 'senha_hash', 'criado_em', 'consentimento_em'],
  cartoes: ['id', 'cliente_id', 'numero', 'status', 'criado_em', 'concluido_em'],
  marcacoes: ['id', 'cartao_id', 'venda_id', 'data_hora'],
  vendas: ['id', 'data_hora', 'tipo', 'valor', 'status', 'codigo', 'expira_em', 'vendedor_id', 'cliente_id', 'marcada_em'],
  cupons: ['id', 'codigo', 'cliente_id', 'cartao_id', 'status', 'gerado_em', 'utilizado_em', 'venda_id']
};
const PREFIXOS = { usuarios: 'U', cartoes: 'C', marcacoes: 'M', vendas: 'V', cupons: 'K' };

const bd = { usuarios: [], cartoes: [], marcacoes: [], vendas: [], cupons: [] };

function arquivoDaTabela(nome) {
  return path.join(PASTA_BANCO, nome + '.txt');
}

/** Remove do texto o que quebraria o formato do arquivo (";" e quebras de linha). */
function limparCampo(valor) {
  if (valor === null || valor === undefined) return '';
  return String(valor)
    .replace(/[\r\n\t]+/g, ' ')
    .replace(/;/g, ',')
    .trim();
}

function carregarTabela(nome) {
  const arquivo = arquivoDaTabela(nome);
  const colunas = TABELAS[nome];
  if (!fs.existsSync(arquivo)) {
    bd[nome] = [];
    salvarTabela(nome);
    return;
  }
  const linhas = fs.readFileSync(arquivo, 'utf8').split(/\r?\n/).filter((linha) => linha.trim() !== '');
  bd[nome] = linhas.slice(1).map((linha) => {
    const campos = linha.split(';');
    const registro = {};
    colunas.forEach((coluna, i) => {
      registro[coluna] = campos[i] === undefined ? '' : campos[i];
    });
    return registro;
  });
}

/** Regrava a tabela inteira. Escreve primeiro em um arquivo temporário e só
    depois troca pelo definitivo, para não corromper o arquivo se algo falhar. */
function salvarTabela(nome) {
  const colunas = TABELAS[nome];
  const linhas = [colunas.join(';')].concat(bd[nome].map((registro) => colunas.map((coluna) => limparCampo(registro[coluna])).join(';')));
  const arquivo = arquivoDaTabela(nome);
  const temporario = arquivo + '.tmp';
  fs.writeFileSync(temporario, linhas.join('\n') + '\n', 'utf8');
  fs.renameSync(temporario, arquivo);
}

function novoId(tabela) {
  const prefixo = PREFIXOS[tabela];
  const maior = bd[tabela].reduce((m, registro) => Math.max(m, Number(String(registro.id).slice(1)) || 0), 0);
  return prefixo + String(maior + 1).padStart(4, '0');
}

/* ----- Segredo usado no código de verificação dos identificadores -----
   Fica em um arquivo separado dos dados. Em produção o ideal é informar pela
   variável de ambiente FIDELIZA_SEGREDO, fora da pasta do banco. */
let SEGREDO = '';
function carregarSegredo() {
  if (process.env.FIDELIZA_SEGREDO) {
    SEGREDO = process.env.FIDELIZA_SEGREDO;
    return;
  }
  const arquivo = path.join(PASTA_BANCO, 'segredo.txt');
  if (fs.existsSync(arquivo)) {
    SEGREDO = fs.readFileSync(arquivo, 'utf8').trim();
  }
  if (!SEGREDO) {
    SEGREDO = crypto.randomBytes(32).toString('hex');
    fs.writeFileSync(arquivo, SEGREDO + '\n', 'utf8');
  }
}

/* ==========================================================================
   Segurança: censura, verificação e senha
   ========================================================================== */
function censurarEmail(email) {
  const partes = String(email).split('@');
  return partes[0].slice(0, 2) + '***@' + (partes[1] || '');
}
function censurarCnpj(cnpj) {
  const d = String(cnpj).replace(/\D/g, '');
  return d.slice(0, 2) + '.***.***/' + d.slice(8, 12) + '-' + d.slice(12, 14);
}
/** Código de verificação do identificador: permite achar o usuário no login
    sem gravar o e-mail/CNPJ. O perfil entra na conta porque vendedor e
    administrador usam o mesmo CNPJ da loja. */
function verificacaoDoIdentificador(perfil, identificador) {
  return crypto.createHmac('sha256', SEGREDO).update(perfil + ':' + identificador).digest('hex');
}
function gerarHashDaSenha(senha, sal) {
  return crypto.scryptSync(String(senha), Buffer.from(sal, 'hex'), 32).toString('hex');
}
function senhaConfere(senha, usuario) {
  const calculado = Buffer.from(gerarHashDaSenha(senha, usuario.senha_sal), 'hex');
  const gravado = Buffer.from(usuario.senha_hash, 'hex');
  return calculado.length === gravado.length && crypto.timingSafeEqual(calculado, gravado);
}
function criarUsuario(perfil, nome, identificador, senha, consentiu) {
  const sal = crypto.randomBytes(16).toString('hex');
  const agora = new Date().toISOString();
  const usuario = {
    id: novoId('usuarios'),
    perfil: perfil,
    nome: limparCampo(nome).slice(0, 60),
    identificador_censurado: perfil === 'cliente' ? censurarEmail(identificador) : censurarCnpj(identificador),
    identificador_verificacao: verificacaoDoIdentificador(perfil, identificador),
    senha_sal: sal,
    senha_hash: gerarHashDaSenha(senha, sal),
    criado_em: agora,
    consentimento_em: consentiu ? agora : ''
  };
  bd.usuarios.push(usuario);
  salvarTabela('usuarios');
  return usuario;
}
function gerarCodigo(tamanho) {
  const bytes = crypto.randomBytes(tamanho);
  let codigo = '';
  for (let i = 0; i < tamanho; i++) codigo += ALFABETO.charAt(bytes[i] % ALFABETO.length);
  return codigo;
}

/* ----- Sessões (ficam só na memória do servidor) ----- */
const sessoes = new Map(); // token -> { usuarioId, expira }
function abrirSessao(usuario) {
  const token = crypto.randomBytes(32).toString('hex');
  sessoes.set(token, { usuarioId: usuario.id, expira: Date.now() + DURACAO_SESSAO_MS });
  return token;
}
function tokenDoPedido(pedido) {
  const cabecalho = String(pedido.headers.authorization || '');
  return cabecalho.indexOf('Bearer ') === 0 ? cabecalho.slice(7).trim() : '';
}
function usuarioDoPedido(pedido) {
  const token = tokenDoPedido(pedido);
  const sessao = token && sessoes.get(token);
  if (!sessao) return null;
  if (sessao.expira < Date.now()) {
    sessoes.delete(token);
    return null;
  }
  return bd.usuarios.find((u) => u.id === sessao.usuarioId) || null;
}
setInterval(() => {
  const agora = Date.now();
  sessoes.forEach((sessao, token) => {
    if (sessao.expira < agora) sessoes.delete(token);
  });
}, 10 * 60 * 1000).unref();

/* ----- Bloqueio temporário depois de várias tentativas erradas ----- */
const tentativas = new Map(); // chave -> { erros, bloqueadoAte }
function estaBloqueado(chave) {
  const t = tentativas.get(chave);
  return !!(t && t.bloqueadoAte > Date.now());
}
function registrarErro(chave, limite, duracaoMs) {
  const t = tentativas.get(chave) || { erros: 0, bloqueadoAte: 0 };
  t.erros += 1;
  if (t.erros >= limite) {
    t.erros = 0;
    t.bloqueadoAte = Date.now() + duracaoMs;
  }
  tentativas.set(chave, t);
}
function limparErros(chave) {
  tentativas.delete(chave);
}

/* ==========================================================================
   Regras de negócio
   ========================================================================== */
class ErroDeRegra extends Error {
  constructor(status, codigo, mensagem) {
    super(mensagem);
    this.status = status;
    this.codigo = codigo;
  }
}
function exigirPerfil(pedido, perfis) {
  const usuario = usuarioDoPedido(pedido);
  if (!usuario) throw new ErroDeRegra(401, 'NAO_AUTENTICADO', 'Faça login para continuar.');
  if (perfis.indexOf(usuario.perfil) < 0) throw new ErroDeRegra(403, 'ACESSO_NEGADO', 'Seu perfil não tem acesso a esta função.');
  return usuario;
}
function usuarioPublico(u) {
  return { id: u.id, nome: u.nome, perfil: u.perfil, identificador: u.identificador_censurado };
}
function nomeDoUsuario(id) {
  const u = id && bd.usuarios.find((x) => x.id === id);
  return u ? u.nome : null;
}
function contatoDoUsuario(id) {
  const u = id && bd.usuarios.find((x) => x.id === id);
  return u ? u.identificador_censurado : null;
}

function cartaoAtual(clienteId) {
  const cartoes = bd.cartoes.filter((c) => c.cliente_id === clienteId);
  return cartoes[cartoes.length - 1] || criarCartao(clienteId);
}
function marcacoesDoCartao(cartaoId) {
  return bd.marcacoes.filter((m) => m.cartao_id === cartaoId);
}
function criarCartao(clienteId) {
  const anteriores = bd.cartoes.filter((c) => c.cliente_id === clienteId).length;
  const cartao = { id: novoId('cartoes'), cliente_id: clienteId, numero: String(anteriores + 1), status: 'ativo', criado_em: new Date().toISOString(), concluido_em: '' };
  bd.cartoes.push(cartao);
  salvarTabela('cartoes');
  return cartao;
}
function visaoDoCartao(cliente) {
  const cartao = cartaoAtual(cliente.id);
  return {
    cartao: {
      id: cartao.id,
      numero: Number(cartao.numero),
      status: cartao.status,
      limite: LIMITE_MARCACOES,
      marcacoes: marcacoesDoCartao(cartao.id).map((m) => ({ id: m.id, dataHora: m.data_hora }))
    },
    cupons: bd.cupons
      .filter((c) => c.cliente_id === cliente.id)
      .map((c) => ({ id: c.id, codigo: c.codigo, status: c.status, geradoEm: c.gerado_em, utilizadoEm: c.utilizado_em || null }))
      .reverse()
  };
}
function vendaPublica(v) {
  return {
    id: v.id,
    dataHora: v.data_hora,
    tipo: v.tipo,
    valor: v.valor === '' ? null : Number(v.valor),
    status: v.status,
    cliente: nomeDoUsuario(v.cliente_id),
    clienteContato: contatoDoUsuario(v.cliente_id),
    vendedor: nomeDoUsuario(v.vendedor_id)
  };
}
/** Marca como expiradas as compras cujo código passou da validade. */
function atualizarExpiracoes() {
  const agora = Date.now();
  let mudou = false;
  bd.vendas.forEach((v) => {
    if (v.status === 'pendente' && v.expira_em && new Date(v.expira_em).getTime() < agora) {
      v.status = 'expirada';
      mudou = true;
    }
  });
  if (mudou) salvarTabela('vendas');
}
function mesmoDia(iso, data) {
  const d = new Date(iso);
  return d.getFullYear() === data.getFullYear() && d.getMonth() === data.getMonth() && d.getDate() === data.getDate();
}
function chaveDia(data) {
  return data.getFullYear() + '-' + String(data.getMonth() + 1).padStart(2, '0') + '-' + String(data.getDate()).padStart(2, '0');
}
function dataHoraLegivel(iso) {
  const d = new Date(iso);
  const dois = (n) => String(n).padStart(2, '0');
  return dois(d.getDate()) + '/' + dois(d.getMonth() + 1) + '/' + d.getFullYear() + ' ' + dois(d.getHours()) + ':' + dois(d.getMinutes());
}
function emailValido(email) {
  return email.length <= 254 && /^[^\s@;]+@[^\s@;]+\.[^\s@;]+$/.test(email);
}

/* ==========================================================================
   Rotas da API
   ========================================================================== */
const rotas = [];
function rota(metodo, padrao, tratador) {
  rotas.push({ metodo: metodo, partes: padrao.split('/').filter(Boolean), tratador: tratador });
}

/* ----- Informações para o QR Code ----- */
rota('GET', '/api/info', (pedido) => ({ urlBase: enderecoPublico(pedido) }));

/* ----- Cadastro e autenticação (RF01, RF02) ----- */
rota('POST', '/api/cadastro', (pedido, corpo) => {
  const nome = limparCampo(corpo.nome);
  const email = String(corpo.email || '').trim().toLowerCase();
  const senha = String(corpo.senha || '');
  if (nome.length < 2) throw new ErroDeRegra(400, 'NOME_INVALIDO', 'Informe seu nome.');
  if (nome.length > 60) throw new ErroDeRegra(400, 'NOME_INVALIDO', 'O nome pode ter no máximo 60 caracteres.');
  if (!emailValido(email)) throw new ErroDeRegra(400, 'EMAIL_INVALIDO', 'Informe um e-mail válido.');
  if (senha.length < TAMANHO_SENHA_MINIMO) throw new ErroDeRegra(400, 'SENHA_FRACA', 'A senha precisa ter pelo menos ' + TAMANHO_SENHA_MINIMO + ' caracteres.');
  if (senha.length > 128) throw new ErroDeRegra(400, 'SENHA_LONGA', 'A senha pode ter no máximo 128 caracteres.');
  if (corpo.consentimento !== true) throw new ErroDeRegra(400, 'SEM_CONSENTIMENTO', 'É preciso autorizar o uso dos dados para participar do programa.');
  const verificacao = verificacaoDoIdentificador('cliente', email);
  if (bd.usuarios.some((u) => u.identificador_verificacao === verificacao)) {
    throw new ErroDeRegra(409, 'EMAIL_JA_CADASTRADO', 'Já existe um cadastro com este e-mail. Use a opção de login.');
  }
  const usuario = criarUsuario('cliente', nome, email, senha, true);
  criarCartao(usuario.id);
  return { status: 201, corpo: { token: abrirSessao(usuario), usuario: usuarioPublico(usuario) } };
});

rota('POST', '/api/login', (pedido, corpo) => {
  const perfil = String(corpo.perfil || '');
  let identificador = String(corpo.identificador || '').trim().toLowerCase();
  const senha = String(corpo.senha || '');
  if (['cliente', 'vendedor', 'administrador'].indexOf(perfil) < 0) throw new ErroDeRegra(400, 'PERFIL_INVALIDO', 'Perfil inválido.');
  if (perfil === 'cliente') {
    if (!emailValido(identificador)) throw new ErroDeRegra(400, 'EMAIL_INVALIDO', 'Informe um e-mail válido.');
  } else {
    identificador = identificador.replace(/\D/g, '');
    if (identificador.length !== 14) throw new ErroDeRegra(400, 'CNPJ_INVALIDO', 'Informe os 14 números do CNPJ.');
  }
  if (!senha) throw new ErroDeRegra(400, 'SENHA_VAZIA', 'Informe a senha.');
  if (senha.length > 128) throw new ErroDeRegra(400, 'SENHA_LONGA', 'A senha pode ter no máximo 128 caracteres.');

  const verificacao = verificacaoDoIdentificador(perfil, identificador);
  const chave = 'login:' + verificacao;
  if (estaBloqueado(chave)) {
    throw new ErroDeRegra(429, 'MUITAS_TENTATIVAS', 'Muitas tentativas seguidas. Aguarde um minuto e tente novamente.');
  }
  const usuario = bd.usuarios.find((u) => u.perfil === perfil && u.identificador_verificacao === verificacao);
  // A mesma mensagem para "usuário não existe" e "senha errada" não revela quem tem cadastro.
  if (!usuario || !senhaConfere(senha, usuario)) {
    registrarErro(chave, TENTATIVAS_LOGIN, BLOQUEIO_LOGIN_MS);
    throw new ErroDeRegra(401, 'CREDENCIAIS_INVALIDAS', (perfil === 'cliente' ? 'E-mail' : 'CNPJ') + ' ou senha incorretos.');
  }
  limparErros(chave);
  if (perfil === 'cliente') cartaoAtual(usuario.id);
  return { token: abrirSessao(usuario), usuario: usuarioPublico(usuario) };
});

rota('POST', '/api/logout', (pedido) => {
  sessoes.delete(tokenDoPedido(pedido));
  return { ok: true };
});

rota('GET', '/api/sessao', (pedido) => {
  const usuario = usuarioDoPedido(pedido);
  return { usuario: usuario ? usuarioPublico(usuario) : null };
});

/* ----- Cliente ----- */

// Cartão atual e cupons do cliente (RF04, RF09)
rota('GET', '/api/cartao', (pedido) => visaoDoCartao(exigirPerfil(pedido, ['cliente'])));

// Registra uma marcação a partir do código lido no QR Code (RF05, RF07, RF08, RF10, RF14)
rota('POST', '/api/marcacoes', (pedido, corpo) => {
  const cliente = exigirPerfil(pedido, ['cliente']);
  const chave = 'codigo:' + cliente.id;
  if (estaBloqueado(chave)) {
    throw new ErroDeRegra(429, 'MUITAS_TENTATIVAS', 'Muitos códigos incorretos em sequência. Aguarde alguns minutos e tente novamente.');
  }
  const codigo = String(corpo.codigo || '').toUpperCase().replace(/[^A-Z0-9]/g, '');
  atualizarExpiracoes();
  // RN03: só existe marcação para uma compra confirmada pelo vendedor (que gerou o código)
  const venda = codigo.length === 6 ? bd.vendas.find((v) => v.codigo === codigo) : null;
  if (!venda) {
    // só conta como tentativa o que tem formato de código (um QR Code qualquer lido por engano não bloqueia)
    if (codigo.length === 6) registrarErro(chave, TENTATIVAS_CODIGO, BLOQUEIO_CODIGO_MS);
    throw new ErroDeRegra(404, 'CODIGO_INVALIDO', 'Código inválido. Confira os 6 caracteres mostrados na tela do vendedor.');
  }
  // RN04: cada código vale para uma única marcação
  if (venda.status === 'marcada') throw new ErroDeRegra(409, 'CODIGO_UTILIZADO', 'Este código já foi utilizado. Cada compra gera uma única marcação.');
  if (venda.status !== 'pendente') throw new ErroDeRegra(410, 'CODIGO_EXPIRADO', 'Este código expirou. Peça ao vendedor para gerar um novo.');

  const cartao = cartaoAtual(cliente.id);
  // RN02 / RF14: no máximo 10 marcações por cartão
  if (cartao.status === 'completo' || marcacoesDoCartao(cartao.id).length >= LIMITE_MARCACOES) {
    throw new ErroDeRegra(409, 'CARTAO_COMPLETO', 'Seu cartão já está completo. Inicie um novo cartão para continuar marcando.');
  }

  const quando = new Date().toISOString();
  venda.status = 'marcada';
  venda.cliente_id = cliente.id;
  venda.marcada_em = quando;
  bd.marcacoes.push({ id: novoId('marcacoes'), cartao_id: cartao.id, venda_id: venda.id, data_hora: quando });

  let cupom = null;
  if (marcacoesDoCartao(cartao.id).length >= LIMITE_MARCACOES) {
    // RN05: cartão completo gera um cupom de 100% de desconto
    cartao.status = 'completo';
    cartao.concluido_em = quando;
    let codigoCupom;
    do {
      codigoCupom = 'CUP-' + gerarCodigo(6);
    } while (bd.cupons.some((c) => c.codigo === codigoCupom));
    cupom = { id: novoId('cupons'), codigo: codigoCupom, cliente_id: cliente.id, cartao_id: cartao.id, status: 'disponivel', gerado_em: quando, utilizado_em: '', venda_id: '' };
    bd.cupons.push(cupom);
    salvarTabela('cartoes');
    salvarTabela('cupons');
  }
  salvarTabela('marcacoes');
  salvarTabela('vendas');
  limparErros(chave);

  const visao = visaoDoCartao(cliente);
  visao.cupomGerado = cupom ? { id: cupom.id, codigo: cupom.codigo, status: cupom.status, geradoEm: cupom.gerado_em } : null;
  return { status: 201, corpo: visao };
});

// Inicia um novo ciclo depois que o cartão foi completado (RN06)
rota('POST', '/api/cartao/novo', (pedido) => {
  const cliente = exigirPerfil(pedido, ['cliente']);
  if (cartaoAtual(cliente.id).status !== 'completo') throw new ErroDeRegra(409, 'CARTAO_INCOMPLETO', 'O cartão atual ainda não foi completado.');
  criarCartao(cliente.id);
  return { status: 201, corpo: visaoDoCartao(cliente) };
});

/* ----- Vendedor e administrador ----- */

// Confirma uma compra e gera o código de uso único mostrado no QR Code (RF06)
rota('POST', '/api/compras', (pedido, corpo) => {
  const vendedor = exigirPerfil(pedido, ['vendedor', 'administrador']);
  let valor = corpo.valor;
  if (valor === undefined || valor === null || valor === '') {
    valor = '';
  } else {
    valor = Number(valor);
    if (!isFinite(valor) || valor <= 0 || valor > 99999) {
      throw new ErroDeRegra(400, 'VALOR_INVALIDO', 'Informe um valor válido para a compra ou deixe o campo em branco.');
    }
    valor = valor.toFixed(2);
  }
  let codigo;
  do {
    codigo = gerarCodigo(6);
  } while (bd.vendas.some((v) => v.codigo === codigo));
  const agora = Date.now();
  const venda = {
    id: novoId('vendas'),
    data_hora: new Date(agora).toISOString(),
    tipo: 'compra',
    valor: valor,
    status: 'pendente',
    codigo: codigo,
    expira_em: new Date(agora + VALIDADE_QR_MINUTOS * 60000).toISOString(),
    vendedor_id: vendedor.id,
    cliente_id: '',
    marcada_em: ''
  };
  bd.vendas.push(venda);
  salvarTabela('vendas');
  return { status: 201, corpo: { id: venda.id, codigo: venda.codigo, expiraEm: venda.expira_em, valor: valor === '' ? null : Number(valor) } };
});

// Situação de uma compra confirmada: pendente, marcada ou expirada
rota('GET', '/api/compras/:id', (pedido, corpo, params) => {
  exigirPerfil(pedido, ['vendedor', 'administrador']);
  atualizarExpiracoes();
  const venda = bd.vendas.find((v) => v.id === params.id && v.tipo === 'compra');
  if (!venda) throw new ErroDeRegra(404, 'NAO_ENCONTRADA', 'Compra não encontrada.');
  let cliente = null;
  let cupomGerado = false;
  if (venda.status === 'marcada') {
    const marcacao = bd.marcacoes.find((m) => m.venda_id === venda.id);
    const doCartao = marcacao ? marcacoesDoCartao(marcacao.cartao_id) : [];
    const posicao = marcacao ? doCartao.indexOf(marcacao) + 1 : 0;
    cliente = { nome: nomeDoUsuario(venda.cliente_id), marcacoes: posicao, limite: LIMITE_MARCACOES };
    cupomGerado = posicao >= LIMITE_MARCACOES;
  }
  return {
    id: venda.id,
    status: venda.status,
    codigo: venda.codigo,
    expiraEm: venda.expira_em,
    valor: venda.valor === '' ? null : Number(venda.valor),
    cliente: cliente,
    cupomGerado: cupomGerado
  };
});

// Valida o cupom de 100% e registra a venda com cupom
rota('POST', '/api/cupons/resgatar', (pedido, corpo) => {
  const vendedor = exigirPerfil(pedido, ['vendedor', 'administrador']);
  let limpo = String(corpo.codigo || '').toUpperCase().replace(/[^A-Z0-9]/g, '');
  if (limpo.indexOf('CUP') === 0) limpo = limpo.slice(3);
  const codigo = 'CUP-' + limpo;
  const cupom = bd.cupons.find((c) => c.codigo === codigo);
  if (!cupom) throw new ErroDeRegra(404, 'CUPOM_INVALIDO', 'Cupom não encontrado. Confira o código mostrado no aplicativo do cliente.');
  if (cupom.status === 'utilizado') {
    throw new ErroDeRegra(409, 'CUPOM_UTILIZADO', 'Este cupom já foi utilizado' + (cupom.utilizado_em ? ' em ' + dataHoraLegivel(cupom.utilizado_em) : '') + '.');
  }
  const quando = new Date().toISOString();
  const venda = {
    id: novoId('vendas'),
    data_hora: quando,
    tipo: 'cupom',
    valor: '0.00',
    status: 'concluida',
    codigo: '',
    expira_em: '',
    vendedor_id: vendedor.id,
    cliente_id: cupom.cliente_id,
    marcada_em: ''
  };
  bd.vendas.push(venda);
  cupom.status = 'utilizado';
  cupom.utilizado_em = quando;
  cupom.venda_id = venda.id;
  salvarTabela('vendas');
  salvarTabela('cupons');
  return { codigo: codigo, cliente: { nome: nomeDoUsuario(cupom.cliente_id) }, utilizadoEm: quando, desconto: DESCONTO_CUPOM };
});

// Indicadores do dia para o painel da loja (RF12)
rota('GET', '/api/resumo', (pedido) => {
  exigirPerfil(pedido, ['vendedor', 'administrador']);
  atualizarExpiracoes();
  const hoje = new Date();
  const vendasHoje = bd.vendas.filter((v) => mesmoDia(v.data_hora, hoje));
  return {
    marcacoesHoje: bd.marcacoes.filter((m) => mesmoDia(m.data_hora, hoje)).length,
    cuponsGeradosHoje: bd.cupons.filter((c) => mesmoDia(c.gerado_em, hoje)).length,
    vendasComCupomHoje: vendasHoje.filter((v) => v.tipo === 'cupom').length,
    ultimas: vendasHoje
      .slice()
      .sort((a, b) => (a.data_hora < b.data_hora ? 1 : -1))
      .slice(0, 6)
      .map(vendaPublica)
  };
});

// Tabela de vendas, histórico e marcações por dia — somente administrador (RF11, RF12, RF13)
rota('GET', '/api/vendas', (pedido, corpo, params, consulta) => {
  exigirPerfil(pedido, ['administrador']);
  atualizarExpiracoes();
  const periodo = ['hoje', '7dias', 'tudo'].indexOf(consulta.get('periodo')) >= 0 ? consulta.get('periodo') : 'hoje';
  const tipo = ['todas', 'compra', 'cupom'].indexOf(consulta.get('tipo')) >= 0 ? consulta.get('tipo') : 'todas';
  const agora = new Date();
  const inicioHoje = new Date(agora.getFullYear(), agora.getMonth(), agora.getDate()).getTime();
  const inicio = periodo === 'hoje' ? inicioHoje : periodo === '7dias' ? new Date(agora.getFullYear(), agora.getMonth(), agora.getDate() - 6).getTime() : 0;
  const lista = bd.vendas
    .filter((v) => new Date(v.data_hora).getTime() >= inicio && (tipo === 'todas' || v.tipo === tipo))
    .sort((a, b) => (a.data_hora < b.data_hora ? 1 : -1));
  const porDia = [];
  for (let i = 6; i >= 0; i--) {
    const dia = new Date(agora.getFullYear(), agora.getMonth(), agora.getDate() - i);
    porDia.push({ dia: chaveDia(dia), total: bd.marcacoes.filter((m) => mesmoDia(m.data_hora, dia)).length });
  }
  return {
    vendas: lista.map(vendaPublica),
    marcacoesPorDia: porDia,
    totais: {
      vendas: lista.filter((v) => v.status === 'marcada' || v.status === 'concluida').length,
      marcacoes: lista.filter((v) => v.status === 'marcada').length,
      cupons: lista.filter((v) => v.tipo === 'cupom').length,
      valor: lista.reduce((soma, v) => soma + (v.status === 'marcada' && v.valor !== '' ? Number(v.valor) : 0), 0)
    }
  };
});

/* ==========================================================================
   Servidor HTTP
   ========================================================================== */
const TIPOS = {
  '.html': 'text/html; charset=utf-8',
  '.css': 'text/css; charset=utf-8',
  '.js': 'text/javascript; charset=utf-8',
  '.json': 'application/json; charset=utf-8',
  '.svg': 'image/svg+xml',
  '.png': 'image/png',
  '.jpg': 'image/jpeg',
  '.ico': 'image/x-icon',
  '.woff2': 'font/woff2',
  '.txt': 'text/plain; charset=utf-8'
};
const CABECALHOS_DE_SEGURANCA = {
  'X-Content-Type-Options': 'nosniff',
  'X-Frame-Options': 'DENY',
  'Referrer-Policy': 'no-referrer',
  'Content-Security-Policy': "default-src 'self'; img-src 'self' data: blob:; media-src 'self' blob:; style-src 'self' 'unsafe-inline'; object-src 'none'; base-uri 'self'; form-action 'self'; frame-ancestors 'none'"
};

function enderecosDaRede() {
  const enderecos = [];
  const interfaces = os.networkInterfaces();
  Object.keys(interfaces).forEach((nome) => {
    (interfaces[nome] || []).forEach((item) => {
      if (item.family === 'IPv4' && !item.internal) enderecos.push(item.address);
    });
  });
  return enderecos;
}
/** Endereço que vai no QR Code. Se o vendedor abriu por "localhost", troca
    pelo endereço da rede local, para o celular do cliente conseguir abrir. */
function enderecoPublico(pedido) {
  const host = String(pedido.headers.host || 'localhost:' + PORTA);
  const nome = host.replace(/:\d+$/, '');
  if (nome === 'localhost' || nome === '127.0.0.1' || nome === '[::1]') {
    const rede = enderecosDaRede();
    if (rede.length) return 'http://' + rede[0] + ':' + PORTA + '/';
  }
  return 'http://' + host + '/';
}

function responderJson(resposta, status, dados) {
  const texto = JSON.stringify(dados);
  resposta.writeHead(status, Object.assign({ 'Content-Type': 'application/json; charset=utf-8', 'Cache-Control': 'no-store', 'Content-Length': Buffer.byteLength(texto) }, CABECALHOS_DE_SEGURANCA));
  resposta.end(texto);
}

function lerCorpo(pedido) {
  return new Promise((resolver, rejeitar) => {
    if (pedido.method === 'GET' || pedido.method === 'HEAD') return resolver({});
    let tamanho = 0;
    const partes = [];
    pedido.on('data', (parte) => {
      tamanho += parte.length;
      if (tamanho > TAMANHO_MAXIMO_CORPO) {
        rejeitar(new ErroDeRegra(413, 'CORPO_GRANDE', 'Os dados enviados são grandes demais.'));
        pedido.destroy();
        return;
      }
      partes.push(parte);
    });
    pedido.on('end', () => {
      const texto = Buffer.concat(partes).toString('utf8').trim();
      if (!texto) return resolver({});
      try {
        const dados = JSON.parse(texto);
        resolver(dados && typeof dados === 'object' && !Array.isArray(dados) ? dados : {});
      } catch (e) {
        rejeitar(new ErroDeRegra(400, 'JSON_INVALIDO', 'Os dados enviados não puderam ser lidos.'));
      }
    });
    pedido.on('error', rejeitar);
  });
}

function atenderApi(pedido, resposta, url) {
  const partes = url.pathname.split('/').filter(Boolean);
  let encontrada = null;
  let params = {};
  let caminhoExiste = false;
  for (const r of rotas) {
    if (r.partes.length !== partes.length) continue;
    const p = {};
    const combina = r.partes.every((parte, i) => {
      if (parte.charAt(0) === ':') {
        p[parte.slice(1)] = decodeURIComponent(partes[i]);
        return true;
      }
      return parte === partes[i];
    });
    if (!combina) continue;
    caminhoExiste = true;
    if (r.metodo === pedido.method) {
      encontrada = r;
      params = p;
      break;
    }
  }
  if (!encontrada) {
    return responderJson(resposta, caminhoExiste ? 405 : 404, { erro: { codigo: caminhoExiste ? 'METODO_NAO_PERMITIDO' : 'NAO_ENCONTRADO', mensagem: 'Operação não encontrada.' } });
  }
  lerCorpo(pedido)
    .then((corpo) => {
      const resultado = encontrada.tratador(pedido, corpo, params, url.searchParams);
      if (resultado && resultado.status && resultado.corpo) return responderJson(resposta, resultado.status, resultado.corpo);
      responderJson(resposta, 200, resultado);
    })
    .catch((e) => {
      if (e instanceof ErroDeRegra) {
        return responderJson(resposta, e.status, { erro: { codigo: e.codigo, mensagem: e.message } });
      }
      console.error('[erro]', e);
      responderJson(resposta, 500, { erro: { codigo: 'ERRO_INTERNO', mensagem: 'O servidor encontrou um problema. Tente novamente.' } });
    });
}

function atenderArquivo(pedido, resposta, url) {
  if (pedido.method !== 'GET' && pedido.method !== 'HEAD') {
    resposta.writeHead(405, CABECALHOS_DE_SEGURANCA);
    return resposta.end();
  }
  let caminho;
  try {
    caminho = decodeURIComponent(url.pathname);
  } catch (e) {
    caminho = '/';
  }
  if (caminho === '/' || caminho === '') caminho = '/index.html';
  // Só entrega arquivos de dentro da pasta "public" (a pasta "database" nunca é exposta).
  const arquivo = path.normalize(path.join(PASTA_PUBLICA, caminho));
  if (arquivo !== PASTA_PUBLICA && arquivo.indexOf(PASTA_PUBLICA + path.sep) !== 0) {
    resposta.writeHead(403, CABECALHOS_DE_SEGURANCA);
    return resposta.end('Acesso negado');
  }
  fs.stat(arquivo, (erro, info) => {
    if (erro || !info.isFile()) {
      resposta.writeHead(404, Object.assign({ 'Content-Type': 'text/plain; charset=utf-8' }, CABECALHOS_DE_SEGURANCA));
      return resposta.end('Página não encontrada');
    }
    const tipo = TIPOS[path.extname(arquivo).toLowerCase()] || 'application/octet-stream';
    resposta.writeHead(200, Object.assign({ 'Content-Type': tipo, 'Content-Length': info.size, 'Cache-Control': 'no-cache' }, CABECALHOS_DE_SEGURANCA));
    if (pedido.method === 'HEAD') return resposta.end();
    fs.createReadStream(arquivo).pipe(resposta);
  });
}

const servidor = http.createServer((pedido, resposta) => {
  let url;
  try {
    url = new URL(pedido.url, 'http://localhost');
  } catch (e) {
    resposta.writeHead(400, CABECALHOS_DE_SEGURANCA);
    return resposta.end();
  }
  if (url.pathname === '/api' || url.pathname.indexOf('/api/') === 0) return atenderApi(pedido, resposta, url);
  atenderArquivo(pedido, resposta, url);
});

/* ==========================================================================
   Início
   ========================================================================== */
function iniciar() {
  fs.mkdirSync(PASTA_BANCO, { recursive: true });
  carregarSegredo();
  Object.keys(TABELAS).forEach(carregarTabela);

  // Contas da loja: criadas somente se ainda não existirem.
  const criadas = [];
  CONTAS_INICIAIS.forEach((conta) => {
    if (!bd.usuarios.some((u) => u.perfil === conta.perfil)) {
      criarUsuario(conta.perfil, conta.nome, conta.identificador, conta.senha, false);
      criadas.push(conta);
    }
  });

  servidor.on('error', (erro) => {
    if (erro.code === 'EADDRINUSE') {
      console.error('\nA porta ' + PORTA + ' já está em uso. Feche o outro programa ou escolha outra porta:');
      console.error('  Windows (cmd):  set PORT=3001 && node server.js');
      console.error('  Linux/macOS:    PORT=3001 node server.js\n');
    } else {
      console.error(erro);
    }
    process.exit(1);
  });

  servidor.listen(PORTA, () => {
    const linhas = ['', 'Fideliza — versão local (banco de dados em .txt)', '', '  Neste computador:  http://localhost:' + PORTA];
    enderecosDaRede().forEach((endereco) => linhas.push('  Na rede (celular): http://' + endereco + ':' + PORTA));
    linhas.push('', '  Dados gravados em: ' + PASTA_BANCO, '');
    linhas.push('  Contas da loja (CNPJ 11.222.333/0001-81):');
    linhas.push('    Vendedor       senha: vendedor123');
    linhas.push('    Administrador  senha: admin123');
    if (criadas.length) linhas.push('    (contas criadas agora, na primeira execução)');
    linhas.push('', '  Clientes: use "Criar cadastro de cliente" na tela inicial.', '  Para encerrar, pressione Ctrl + C.', '');
    console.log(linhas.join('\n'));
  });
}

iniciar();
