#!/usr/bin/env sh
# Inicia a versão local do Fideliza (Linux e macOS).
cd "$(dirname "$0")" || exit 1
if ! command -v node >/dev/null 2>&1; then
  echo "O Node.js não foi encontrado. Instale a versão LTS em https://nodejs.org e tente de novo."
  exit 1
fi
exec node server.js
