/* ==========================================================================
   Camada de dados — VERSÃO LOCAL (banco de dados em arquivos .txt)

   - Conversa com o servidor local (server.js) pelos endereços /api/...
   - Os dados ficam gravados na pasta "database" do servidor, em arquivos .txt.
   - E-mails e CNPJs são gravados censurados (ex.: ed***@gmail.com) e as
     senhas são gravadas apenas como hash (scrypt). Nada disso volta para o
     navegador em texto puro.

   A interface pública (Fideliza.api) é idêntica à da versão de demonstração,
   por isso as telas funcionam sem alteração nas duas versões.
   ========================================================================== */
(function () {
  'use strict';
  var Fideliza = (window.Fideliza = window.Fideliza || {});

  var CHAVE_SESSAO = 'fideliza.token';
  var tokenEmMemoria = null;

  /* O token da sessão fica no sessionStorage: vale só para a aba aberta e é
     apagado quando a aba é fechada ou quando a pessoa clica em "Sair". */
  function lerToken() {
    if (tokenEmMemoria) return tokenEmMemoria;
    try {
      tokenEmMemoria = window.sessionStorage.getItem(CHAVE_SESSAO);
    } catch (e) {
      tokenEmMemoria = null;
    }
    return tokenEmMemoria;
  }
  function guardarToken(token) {
    tokenEmMemoria = token || null;
    try {
      if (token) window.sessionStorage.setItem(CHAVE_SESSAO, token);
      else window.sessionStorage.removeItem(CHAVE_SESSAO);
    } catch (e) {
      /* sem sessionStorage a sessão vale até a página ser recarregada */
    }
  }

  function erro(mensagem, codigo) {
    var e = new Error(mensagem);
    e.codigo = codigo || 'ERRO';
    return e;
  }

  /** Faz uma chamada ao servidor e devolve o JSON da resposta. */
  function chamar(metodo, caminho, corpo) {
    if (window.location.protocol === 'file:') {
      return Promise.reject(
        erro('Esta versão precisa do servidor local. Execute "node server.js" e abra o endereço http://localhost:3000 no navegador.', 'SEM_SERVIDOR')
      );
    }
    var cabecalhos = { Accept: 'application/json' };
    var token = lerToken();
    if (token) cabecalhos.Authorization = 'Bearer ' + token;
    var opcoes = { method: metodo, headers: cabecalhos, cache: 'no-store' };
    if (corpo !== undefined) {
      cabecalhos['Content-Type'] = 'application/json';
      opcoes.body = JSON.stringify(corpo);
    }
    return fetch('/api' + caminho, opcoes)
      .catch(function () {
        throw erro('Não foi possível falar com o servidor. Verifique se o servidor local continua em execução.', 'SEM_CONEXAO');
      })
      .then(function (resposta) {
        return resposta
          .json()
          .catch(function () {
            return null;
          })
          .then(function (dados) {
            if (resposta.ok) return dados;
            var detalhe = (dados && dados.erro) || {};
            if (detalhe.codigo === 'NAO_AUTENTICADO') guardarToken(null);
            throw erro(detalhe.mensagem || 'O servidor não conseguiu concluir a operação. Tente novamente.', detalhe.codigo || 'ERRO_SERVIDOR');
          });
      });
  }

  function consulta(filtros) {
    var partes = [];
    Object.keys(filtros || {}).forEach(function (chave) {
      if (filtros[chave] !== undefined && filtros[chave] !== null) {
        partes.push(encodeURIComponent(chave) + '=' + encodeURIComponent(filtros[chave]));
      }
    });
    return partes.length ? '?' + partes.join('&') : '';
  }

  /* ======================================================================
     Interface pública
     ====================================================================== */
  Fideliza.api = {
    modo: 'local',

    /** Endereço do site, usado nos QR Codes. O servidor informa o endereço da
        rede local para que o QR Code não aponte para "localhost". */
    urlBase: function () {
      return chamar('GET', '/info')
        .then(function (info) {
          return info.urlBase;
        })
        .catch(function () {
          return String(window.location.href).split('#')[0];
        });
    },

    sessao: function () {
      if (!lerToken()) return Promise.resolve(null);
      return chamar('GET', '/sessao').then(function (dados) {
        if (!dados.usuario) guardarToken(null);
        return dados.usuario;
      });
    },

    /** Cadastro de cliente (RF01). */
    cadastrar: function (dados) {
      return chamar('POST', '/cadastro', {
        nome: dados.nome,
        email: dados.email,
        senha: dados.senha,
        consentimento: !!dados.consentimento
      }).then(function (resposta) {
        guardarToken(resposta.token);
        return resposta.usuario;
      });
    },

    /** Login de cliente, vendedor ou administrador (RF02). */
    login: function (dados) {
      return chamar('POST', '/login', {
        perfil: dados.perfil,
        identificador: dados.identificador,
        senha: dados.senha
      }).then(function (resposta) {
        guardarToken(resposta.token);
        return resposta.usuario;
      });
    },

    sair: function () {
      var pedido = lerToken() ? chamar('POST', '/logout', {}) : Promise.resolve();
      return pedido
        .catch(function () {
          /* mesmo sem resposta do servidor, a sessão é apagada neste aparelho */
        })
        .then(function () {
          guardarToken(null);
        });
    },

    /* ----- Cliente ----- */

    /** Cartão atual e cupons do cliente (RF04, RF09). */
    cartao: function () {
      return chamar('GET', '/cartao');
    },

    /** Registra uma marcação a partir do código lido no QR Code (RF05, RF07, RF08, RF10, RF14). */
    marcar: function (codigo) {
      return chamar('POST', '/marcacoes', { codigo: codigo });
    },

    /** Inicia um novo ciclo depois que o cartão foi completado (RN06). */
    novoCartao: function () {
      return chamar('POST', '/cartao/novo', {});
    },

    /* ----- Vendedor e administrador ----- */

    /** Confirma uma compra e gera o código de uso único mostrado no QR Code (RF06). */
    confirmarCompra: function (valor) {
      return chamar('POST', '/compras', { valor: valor === undefined ? null : valor });
    },

    /** Situação de uma compra confirmada: pendente, marcada ou expirada. */
    statusCompra: function (id) {
      return chamar('GET', '/compras/' + encodeURIComponent(id));
    },

    /** Valida o cupom de 100% e registra a venda com cupom. */
    resgatarCupom: function (codigo) {
      return chamar('POST', '/cupons/resgatar', { codigo: codigo });
    },

    /** Indicadores do dia para o painel da loja (RF12). */
    resumo: function () {
      return chamar('GET', '/resumo');
    },

    /** Tabela de vendas, histórico e marcações por dia — somente administrador (RF11, RF12, RF13). */
    vendas: function (filtros) {
      return chamar('GET', '/vendas' + consulta(filtros));
    }
  };
})();
